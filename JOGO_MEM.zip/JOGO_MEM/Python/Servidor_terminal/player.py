import websockets
import asyncio
import aioconsole   # precisa instalar: pip install aioconsole
import sys          

flag = False
player_id = None
ROWS, COLS = 6, 8

# Recebe mensagens do servidor
async def receber_msg(websocket):
    global flag, player_id
    try:
        async for msg in websocket:
            server_message = msg.strip()
            print(f"\n[Servidor] {server_message}")

            # Identifica o jogador
            if server_message.startswith("WELCOME PLAYER"):
                player_id = int(server_message.split()[-1])
                print(f"✅ Você é o Jogador {player_id}")

            # Controle de turno
            if "YOUR_TURN" in server_message:
                flag = True
                print("👉 É sua vez de jogar!")
            elif "WAIT" in server_message:
                flag = False
                print("⏳ Aguarde sua vez...")

            # Fim de jogo
            if server_message.startswith("END"):
                print("Servidor encerrou a partida.")
                await websocket.close()
                break
    except websockets.ConnectionClosed:
        print("Conexão encerrada pelo servidor.")

# Envia um comando TURN
async def turn_card(websocket, msg):
    global flag
    if flag:
        mainstring = msg.upper().split()
        if len(mainstring) == 3 and mainstring[0] == "TURN":
            if mainstring[1].isdigit() and mainstring[2].isdigit():
                row, col = int(mainstring[1]), int(mainstring[2])
                if 0 <= row < ROWS and 0 <= col < COLS:
                    await websocket.send(msg + "\n")
                else:
                    print(f"Coordenadas fora do limite: use 0 ≤ row < {ROWS}, 0 ≤ col < {COLS}.")
            else:
                print("Os argumentos após TURN devem ser números.")
        else:
            print("Formato inválido. Use: TURN row col")
    else:
        print("⚠ Não é sua vez ainda. Aguarde o servidor.")

# Encerra a conexão
async def end(websocket):
    print("Encerrando a conexão com o servidor.")
    await websocket.send("END")
    
# Lê comandos do usuário sem travar o loop
async def input_read(websocket):
    print("Comandos disponíveis: TURN row col, END")
    while True:
        comando = await aioconsole.ainput("Insira o comando: ")
        comando = comando.strip()
        if comando.upper() == "END":
            await end(websocket)
            break
        else:
            await turn_card(websocket, comando)

# Função principal
async def connect(ip, porta):
    uri = f"ws://{ip}:{porta}"  # ajuste para o IP/porta do servidor
    async with websockets.connect(uri) as websocket:
        print("Conectado ao servidor.")

        # Envia CONNECT
        await websocket.send("CONNECT\n")

        # Cria tarefas de envio e recebimento
        receber = asyncio.create_task(receber_msg(websocket))
        enviar = asyncio.create_task(input_read(websocket))
        await asyncio.gather(receber, enviar)

# Entry point
async def main():
    if len(sys.argv) != 3:
        print("Use: python player.py <IP> <PORTA>")
        return
    ip = sys.argv[1]
    port = int(sys.argv[2])
    await connect(ip, port)

asyncio.run(main())